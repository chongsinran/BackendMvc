const amqp = require('amqplib');

let channel;
const lastMessages = {}; // In-memory store for last messages

const connectRabbitMQ = async () => {
  try {
    const connection = await amqp.connect(process.env.RABBITMQ_URL);
    channel = await connection.createChannel();
    await channel.assertExchange('socket-exchange', 'topic', { durable: true });
    console.log('Connected to RabbitMQ and channel created');
  } catch (error) {
    console.error('Error connecting to RabbitMQ:', error);
    throw error;
  }
};

const publishMessage = async (topic, message) => {
  if (!channel) {
    await connectRabbitMQ();
  }
  channel.publish('socket-exchange', topic, Buffer.from(message), { persistent: true });
  lastMessages[topic] = message; // Store the last message for the topic
  console.log(`Message published to topic "${topic}": ${message}`);
};

const subscribeToTopic = async (topic, onMessage) => {
  if (!channel) {
    await connectRabbitMQ();
  }
  const q = await channel.assertQueue('', { exclusive: true, durable: true });
  await channel.bindQueue(q.queue, 'socket-exchange', topic);
  channel.consume(q.queue, (msg) => {
    if (msg.content) {
      const message = msg.content.toString();
      console.log(`Message received on topic "${topic}": ${message}`);
      onMessage(message);
    }
  }, { noAck: true });
};

const getLastMessage = (topic) => {
  return lastMessages[topic];
};

module.exports = {
  connectRabbitMQ,
  publishMessage,
  subscribeToTopic,
  getLastMessage
};
