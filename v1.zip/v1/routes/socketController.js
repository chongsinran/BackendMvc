const express = require('express');
const router = express.Router();
const { connectRabbitMQ } = require('../models/socketControllerModel');

router.get('/initialize', async (req, res) => {
  try {
    await connectRabbitMQ();
    res.status(200).json({ message: 'RabbitMQ initialized' });
  } catch (error) {
    res.status(500).json({ message: 'Error initializing RabbitMQ', error: error.message });
  }
});

module.exports = router;