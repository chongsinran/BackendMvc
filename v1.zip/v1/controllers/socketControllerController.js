const { connectRabbitMQ, publishMessage, subscribeToTopic, getLastMessage } = require('../models/socketControllerModel');

const handleSocketV1 = (socket) => {
  console.log('New client connected:', socket.id);

  socket.on('subscribe', async (topic) => {
    console.log(`Client ${socket.id} subscribed to topic "${topic}"`);
    const lastMessage = getLastMessage(topic);
    if (lastMessage) {
      socket.emit(topic, lastMessage); // Send the last message immediately after subscribing
    }
    await subscribeToTopic(topic, (message) => {
      socket.emit(topic, message);
    });
  });

  socket.on('publish', async ({ topic, message }) => {
    console.log(`Publishing message to topic "${topic}": ${message}`);
    await publishMessage(topic, message);
  });

  socket.on('disconnect', () => {
    console.log('Client disconnected:', socket.id);
  });
};

const initializeSocketIO = async (io) => {
  await connectRabbitMQ();
  io.of('/v1').on('connection', handleSocketV1);
};

module.exports = {
  handleSocketV1,
  initializeSocketIO
};
